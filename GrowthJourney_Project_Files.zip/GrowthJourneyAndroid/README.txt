GROWTH JOURNEY ANDROID PROJECT
==============================

Native Android Studio project (Java), not a precompiled APK.
Features: daily habit check-ins, date picker, weekly overview, add/edit/delete habits,
daily report copy, local persistence using Android SharedPreferences.

BUILD ON A COMPUTER:
1. Open this folder in Android Studio.
2. Let Gradle sync finish.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).

BUILD USING ONLY YOUR PHONE (cloud build):
1. Create/sign in to a GitHub account in Chrome.
2. Create a new repository named GrowthJourney (public is easiest for a first attempt).
3. Upload the CONTENTS of this project ZIP to the repository root, including the hidden
   .github/workflows/build-apk.yml file. If GitHub's web uploader hides dot-folders,
   use github.dev or a file-upload method that includes .github.
4. Open the repository's Actions tab.
5. Select "Build Growth Journey APK" and tap "Run workflow" (or push to main).
6. When the run finishes successfully, open the run, scroll to Artifacts, and download
   growth-journey-debug-apk. Extract the downloaded artifact ZIP to get app-debug.apk.
7. Open the APK on your Android phone and install it. Android may ask to allow installs
   from Chrome or Files; only allow it for the source you trust.

The included GitHub Actions workflow builds a debug APK in the cloud. It has not been
run or verified in this environment. The app stores habits locally on the device.
