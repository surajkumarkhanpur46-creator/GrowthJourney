package com.growthjourney.app;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import android.text.InputType;
import org.json.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    int bg=Color.rgb(15,19,16), panel=Color.rgb(29,36,31), panel2=Color.rgb(38,48,41);
    int green=Color.rgb(157,231,177), muted=Color.rgb(174,188,178), white=Color.WHITE;
    LinearLayout root, content, nav; String screen="Daily", selectedDate=today();
    ArrayList<Habit> habits=new ArrayList<>(); JSONObject records;
    class Habit { String id,name,target; Habit(String i,String n,String t){id=i;name=n;target=t;} }
    String today(){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());}
    String pretty(String s){try{return new SimpleDateFormat("EEE, dd MMM yyyy",Locale.getDefault()).format(new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(s));}catch(Exception e){return s;}}
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);load();show();}
    void load(){
        android.content.SharedPreferences p=getSharedPreferences("growth_journey",0);
        records=new JSONObject(); try{records=new JSONObject(p.getString("records","{}"));}catch(Exception ignored){}
        try{
            JSONArray a=new JSONArray(p.getString("habits",""));
            for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);habits.add(new Habit(o.getString("id"),o.getString("name"),o.optString("target","Daily")));}
        }catch(Exception e){
            String[][] defaults={{"h1","🌅 Wake up early","5:00 AM"},{"h2","💧 Water intake","2.5 litres"},{"h3","💪 Gym / Workout","As planned"},{"h4","🧘 Meditation","10 minutes"},{"h5","📚 Study","Daily session"},{"h6","💻 SHYFT Deep Work","3 hours"},{"h7","🧠 Learn something new","20 minutes"},{"h8","📵 Avoid distractions","Mindful phone use"},{"h9","😴 Sleep on time","9:30 PM"},{"h10","📝 Plan tomorrow","5 minutes"},{"h11","📖 Read a book","10 pages"}};
            for(String[] d:defaults)habits.add(new Habit(d[0],d[1],d[2]));save();
        }
    }
    void save(){
        try{JSONArray a=new JSONArray();for(Habit h:habits){JSONObject o=new JSONObject();o.put("id",h.id);o.put("name",h.name);o.put("target",h.target);a.put(o);}getSharedPreferences("growth_journey",0).edit().putString("habits",a.toString()).putString("records",records.toString()).apply();}catch(Exception ignored){}
    }
    GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);return d;}
    TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);t.setPadding(0,4,0,4);return t;}
    LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    void gap(LinearLayout p,int h){View v=new View(this);p.addView(v,lp(1,h));}
    Button button(String s,Runnable action,boolean primary){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(13);b.setTextColor(primary?bg:white);b.setBackground(shape(primary?green:panel2,24));b.setOnClickListener(v->action.run());return b;}
    void show(){
        root=column();root.setBackgroundColor(bg);root.setPadding(18,18,18,16);
        ScrollView scroll=new ScrollView(this);content=column();scroll.addView(content);
        TextView eyebrow=text("YOUR PERSONAL SYSTEM",11,green,true);content.addView(eyebrow);
        content.addView(text("Growth Journey 🚀",28,white,true));
        content.addView(text("Small steps. Every day.",14,muted,false));gap(content,18);
        nav=row();String[] tabs={"Daily","History","Edit habits"};
        for(String tab:tabs){Button b=button(tab,()->{screen=tab;show();},screen.equals(tab));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,52,1);p.setMargins(2,0,2,0);nav.addView(b,p);}content.addView(nav);gap(content,12);
        if(screen.equals("Daily"))daily();else if(screen.equals("History"))history();else manage();
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
    }
    JSONObject dateRecord(String date){JSONObject o=records.optJSONObject(date);if(o==null){o=new JSONObject();recordsSafe(date,o);}return o;}
    void recordsSafe(String d,JSONObject o){try{records.put(d,o);}catch(Exception ignored){}}
    boolean done(String date,String id){return dateRecord(date).optBoolean(id,false);}
    int count(String date){int n=0;for(Habit h:habits)if(done(date,h.id))n++;return n;}
    void toggle(String date,Habit h){JSONObject o=dateRecord(date);try{o.put(h.id,!o.optBoolean(h.id,false));}catch(Exception ignored){}save();show();}
    void card(LinearLayout parent,View child){LinearLayout box=column();box.setPadding(14,12,14,12);box.setBackground(shape(panel,22));box.addView(child);LinearLayout.LayoutParams p=lp(-1,-2);p.setMargins(0,5,0,7);parent.addView(box,p);}
    void daily(){
        LinearLayout dateRow=row();dateRow.addView(text(pretty(selectedDate),15,white,true),new LinearLayout.LayoutParams(0,-2,1));
        dateRow.addView(button("Change date",()->dateDialog(),false));card(content,dateRow);
        int n=count(selectedDate),pct=habits.isEmpty()?0:n*100/habits.size();
        LinearLayout stats=row();stats.addView(text("Done  "+n+"/"+habits.size()+"     "+pct+"% progress",17,green,true));card(content,stats);
        for(Habit h:habits){boolean yes=done(selectedDate,h.id);LinearLayout r=row();TextView check=text(yes?"● ✓":"○",23,yes?green:muted,true);r.addView(check);LinearLayout info=column();info.addView(text(h.name,16,white,true));info.addView(text(h.target,12,muted,false));LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(0,-2,1);ip.setMargins(12,0,0,0);r.addView(info,ip);LinearLayout box=column();box.setPadding(14,9,14,9);box.setBackground(shape(yes?Color.rgb(33,54,39):panel,18));box.addView(r);box.setOnClickListener(v->toggle(selectedDate,h));LinearLayout.LayoutParams p=lp(-1,-2);p.setMargins(0,4,0,4);content.addView(box,p);}
        gap(content,8);content.addView(button("Copy daily report",()->copyReport(),true),lp(-1,52));
    }
    void dateDialog(){DatePickerDialog d=new DatePickerDialog(this,(v,y,m,day)->{selectedDate=String.format(Locale.US,"%04d-%02d-%02d",y,m+1,day);show();},Integer.parseInt(selectedDate.substring(0,4)),Integer.parseInt(selectedDate.substring(5,7))-1,Integer.parseInt(selectedDate.substring(8,10)));d.show();}
    void history(){
        content.addView(text("Weekly overview",21,white,true));content.addView(text("Tap a day to review its habits.",13,muted,false));gap(content,8);
        Calendar c=Calendar.getInstance();try{c.setTime(new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(selectedDate));}catch(Exception ignored){}
        int dow=c.get(Calendar.DAY_OF_WEEK);c.add(Calendar.DAY_OF_MONTH, dow==1?-6:2-dow);
        int total=0;
        for(int i=0;i<7;i++){String date=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime());int n=count(date);total+=n;LinearLayout r=row();r.addView(text(new SimpleDateFormat("EEE dd",Locale.US).format(c.getTime()),14,green,true),new LinearLayout.LayoutParams(0,-2,1));r.addView(text(n+"/"+habits.size()+" complete",14,white,false));r.setPadding(12,12,12,12);r.setBackground(shape(panel,16));r.setOnClickListener(v->{selectedDate=date;screen="Daily";show();});LinearLayout.LayoutParams p=lp(-1,-2);p.setMargins(0,4,0,4);content.addView(r,p);c.add(Calendar.DAY_OF_MONTH,1);}
        card(content,text("Weekly check-ins: "+total,17,green,true));content.addView(button("Choose another date",()->dateDialog(),false),lp(-1,50));
    }
    void manage(){
        content.addView(text("Manage your habits",21,white,true));content.addView(text("Add, edit or delete habits anytime.",13,muted,false));gap(content,8);
        content.addView(button("+ Add new habit",()->habitDialog(null),true),lp(-1,52));gap(content,8);
        for(Habit h:new ArrayList<>(habits)){LinearLayout r=column();r.addView(text(h.name,16,white,true));r.addView(text(h.target,12,muted,false));LinearLayout actions=row();actions.addView(button("Edit",()->habitDialog(h),false),new LinearLayout.LayoutParams(0,48,1));actions.addView(button("Delete",()->new AlertDialog.Builder(this).setTitle("Delete habit?").setMessage("Remove "+h.name+" and its check-in history?").setNegativeButton("Cancel",null).setPositiveButton("Delete",(a,b)->{habits.remove(h);for(java.util.Iterator<String> it=records.keys();it.hasNext();)records.optJSONObject(it.next());try{for(String key:keys(records))records.optJSONObject(key).remove(h.id);}catch(Exception ignored){}save();show();}).show(),false),new LinearLayout.LayoutParams(0,48,1));r.addView(actions);card(content,r);}
    }
    ArrayList<String> keys(JSONObject o){ArrayList<String> a=new ArrayList<>();Iterator<String> i=o.keys();while(i.hasNext())a.add(i.next());return a;}
    void habitDialog(Habit h){
        LinearLayout form=column();form.setPadding(18,6,18,0);EditText name=new EditText(this);name.setSingleLine(true);name.setHint("Habit name");name.setTextColor(white);name.setHintTextColor(muted);name.setText(h==null?"":h.name);form.addView(name);
        EditText target=new EditText(this);target.setSingleLine(true);target.setHint("Target (e.g. 10 pages)");target.setTextColor(white);target.setHintTextColor(muted);target.setText(h==null?"":h.target);form.addView(target);
        new AlertDialog.Builder(this).setTitle(h==null?"Add habit":"Edit habit").setView(form).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{String nm=name.getText().toString().trim();if(nm.isEmpty()){Toast.makeText(this,"Enter a habit name",Toast.LENGTH_SHORT).show();return;}String tg=target.getText().toString().trim();if(tg.isEmpty())tg="Daily";if(h==null)habits.add(new Habit("h"+System.currentTimeMillis(),nm,tg));else{h.name=nm;h.target=tg;}save();show();}).show();
    }
    void copyReport(){
        StringBuilder s=new StringBuilder("Growth Journey — "+pretty(selectedDate)+"\n");
        for(Habit h:habits)s.append(done(selectedDate,h.id)?"✅ ":"⬜ ").append(h.name).append(" (").append(h.target).append(")\n");
        s.append("Progress: ").append(count(selectedDate)).append("/").append(habits.size());
        android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);cm.setPrimaryClip(android.content.ClipData.newPlainText("Habit report",s.toString()));Toast.makeText(this,"Daily report copied",Toast.LENGTH_SHORT).show();
    }
}